# 引入数据集，sklearn包含众多数据集
from sklearn import datasets
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import cross_val_score
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
import warnings
warnings.filterwarnings('ignore')
#使用预处理
from sklearn import preprocessing
from sklearn.svm import SVC

S=[]
T={}
D={}
with open('../data/MAHNOB-HCI/valence_arousal_label.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
T['valence_arousal_label'] = S
S=[]
with open('../data/MAHNOB-HCI/EEG_feature.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([float(i) for i in line])
T['EEG_feature'] = S
S=[]
with open('../data/MAHNOB-HCI/subject_video.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
T['subject_video'] = S
S=[]
with open('../data/MAHNOB-HCI/EEG_emotion_category.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
T['EEG_emotion_category'] = S

S = []
with open('../data/DEAP/EEG_feature.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([float(i) for i in line])
D['EEG_feature'] = S
S = []
with open('../data/DEAP/subject_video.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
D['subject_video'] = S
S = []
with open('../data/DEAP/valence_arousal_label.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
D['valence_arousal_label'] = S
#DEAP
length = len(D['EEG_feature'])
X = []
for x in range(0,length):
	X.append(D['EEG_feature'][x] + D['valence_arousal_label'][x])
scaler = preprocessing.MinMaxScaler()
X = scaler.fit_transform(X).tolist()
Y = [x[0] for x in D['subject_video'] ]
#归一化
model =MultinomialNB()
scores = cross_val_score(model, X, Y,cv=5)
print("Cross validation scores:{}".format(scores))
print("Mean cross validation score:{:2f}".format(scores.mean()))
#MAHNOB
length = len(T['EEG_feature'])
X = []
for x in range(0,length):
	X.append(T['EEG_feature'][x] + T['valence_arousal_label'][x])
scaler = preprocessing.MinMaxScaler()
X = scaler.fit_transform(X).tolist()
Y = [x[0] for x in T['subject_video'] ]
Y2 = [x[0] for x in T['EEG_emotion_category'] ]
#归一化
model =MultinomialNB()
scores = cross_val_score(model, X, Y,cv=5)
print("Cross validation scores:{}".format(scores))
print("Mean cross validation score:{:2f}".format(scores.mean()))
X = []
for x in range(0,length):
	X.append(T['EEG_feature'][x] + T['valence_arousal_label'][x]+T['subject_video'][x])
model =MultinomialNB()
scores = cross_val_score(model, X, Y2,cv=5)
print("Cross validation scores:{}".format(scores))
print("Mean cross validation score:{:2f}".format(scores.mean()))