# 引入数据集，sklearn包含众多数据集
from sklearn import datasets
from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import cross_val_score
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
import warnings
warnings.filterwarnings('ignore')
#使用预处理
from sklearn import preprocessing
from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV
import numpy as np
# 将数据分为测试集和训练集
from sklearn.model_selection import train_test_split
# 利用邻近点方式训练数据
from sklearn.neighbors import KNeighborsClassifier
S=[]
T={}
D={}
with open('./data/MAHNOB-HCI/valence_arousal_label.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
T['valence_arousal_label'] = S
S=[]
with open('./data/MAHNOB-HCI/EEG_feature.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([float(i) for i in line])
T['EEG_feature'] = S
S=[]
with open('./data/MAHNOB-HCI/subject_video.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
T['subject_video'] = S
S=[]
with open('./data/MAHNOB-HCI/EEG_emotion_category.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
T['EEG_emotion_category'] = S

S = []
with open('./data/DEAP/EEG_feature.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([float(i) for i in line])
D['EEG_feature'] = S
S = []
with open('./data/DEAP/subject_video.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
D['subject_video'] = S
S = []
with open('./data/DEAP/valence_arousal_label.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
D['valence_arousal_label'] = S
# 特征变量
length = len(T['EEG_emotion_category'])
X =  []
ohe = OneHotEncoder(categorical_features=[0])
L = T['EEG_feature']
scaler = preprocessing.MinMaxScaler()
L = scaler.fit_transform(L).tolist()
#最大最小处理
P = ohe.fit_transform(T['EEG_emotion_category']).toarray().tolist()
#独热码
#print(P)
for i in range(0,length):
	tem = L[i]+P[i]
	X.append(tem)
#print(X)
#正则化
#X = preprocessing.normalize(X, norm='l2')
#print(X)
Y = [x[0]*x[1] for x in T['valence_arousal_label'] ]
Y0 = [x[0]-1 for x in T['valence_arousal_label']]
Y1 = [x[1]-1 for x in T['valence_arousal_label']]
print('目标值', Y0,Y1)
# 利用train_test_split进行训练集和测试机进行分开，test_size占30%
#X_train, X_test, y_train, y_test = train_test_split(X, Y0, test_size=0.3)
# 我们看到训练数据的特征值分为3类
# print(y_train)
# 训练数据
# 引入训练方法
model = SVC(C= 8, kernel='rbf', gamma='auto')
# 进行填充测试数据进行训练
'''
model.fit(X_train, y_train)

params = model.get_params()
print(params)
score = model.score(X_train, y_train)
print("训练得分为：%s" % score)
score = model.score(X_test, y_test)
print("预测得分为：%s" % score)
'''
scores = cross_val_score(model, X, Y0,cv=5)

print("Cross validation scores:{}".format(scores))
print("Mean cross validation score:{:2f}".format(scores.mean()))
# 预测数据，预测特征值
#print(model.predict(X_test))

# 打印真实特征值
#print([y+1 for y in Y0])

#X_train, X_test, y_train, y_test = train_test_split(X, Y1, test_size=0.3)
# 我们看到训练数据的特征值分为3类
# print(y_train)
# 训练数据
# 引入训练方法
model = SVC(C=12, kernel='rbf', gamma='auto')
# 进行填充测试数据进行训练
'''
model.fit(X_train, y_train)

params = model.get_params()
print(params)
score = model.score(X_train, y_train)
print("训练得分为：%s" % score)
score = model.score(X_test, y_test)
print("预测得分为：%s" % score)
'''
scores = cross_val_score(model, X, Y1,cv=5)

print("Cross validation scores:{}".format(scores))
print("Mean cross validation score:{:2f}".format(scores.mean()))

# 预测数据，预测特征值
#print(model.predict(X_test))

# 打印真实特征值
#print([y+1 for y in Y1])
'''
model = SVC(C= 8, kernel='rbf', gamma='auto')
scores = cross_val_score(model, X, Y)
print("Cross validation scores:{}".format(scores))
print("Mean cross validation score:{:2f}".format(scores.mean()))
'''
X = D['EEG_feature']
scaler = preprocessing.MinMaxScaler()
X = scaler.fit_transform(X).tolist()
Y = [x[0]*x[1] for x in D['valence_arousal_label'] ]
Y0 = [x[0]-1 for x in D['valence_arousal_label']]
Y1 = [x[1]-1 for x in D['valence_arousal_label']]
model = SVC(C=.53, kernel='rbf')
scores = cross_val_score(model, X, Y0,cv=5)
print("Cross validation scores:{}".format(scores))
print("Mean cross validation score:{:2f}".format(scores.mean()))
model = SVC(C= 1, kernel='rbf', gamma='auto')
scores = cross_val_score(model, X, Y1,cv=5)
print("Cross validation scores:{}".format(scores))
print("Mean cross validation score:{:2f}".format(scores.mean()))
