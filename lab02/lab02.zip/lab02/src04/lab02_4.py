# 引入数据集，sklearn包含众多数据集
from sklearn import datasets
from sklearn.linear_model import LogisticRegression

from sklearn.preprocessing import OneHotEncoder
from sklearn.model_selection import cross_val_score
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
import warnings
warnings.filterwarnings('ignore')
#使用预处理
from sklearn import preprocessing
from sklearn.svm import SVC

S=[]
T={}
D={}
with open('../data/MAHNOB-HCI/valence_arousal_label.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
T['valence_arousal_label'] = S
S=[]
with open('../data/MAHNOB-HCI/EEG_feature.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([float(i) for i in line])
T['EEG_feature'] = S
S=[]
with open('../data/MAHNOB-HCI/subject_video.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
T['subject_video'] = S
S=[]
with open('../data/MAHNOB-HCI/EEG_emotion_category.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
T['EEG_emotion_category'] = S

S = []
with open('../data/DEAP/EEG_feature.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([float(i) for i in line])
D['EEG_feature'] = S
S = []
with open('../data/DEAP/subject_video.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
D['subject_video'] = S
S = []
with open('../data/DEAP/valence_arousal_label.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
D['valence_arousal_label'] = S
ohe = OneHotEncoder(categorical_features=[0])
W = ohe.fit_transform([[x[0]] for x in D['subject_video']]).toarray().tolist()
#DEAP
length = len(D['EEG_feature'])
X = []
for x in range(0,length):
	X.append(D['EEG_feature'][x] + D['subject_video'][x])
scaler = preprocessing.MinMaxScaler()
X = scaler.fit_transform(X).tolist()
Y = [x[0]*x[1] for x in D['valence_arousal_label'] ]
Y0 = [x[0]-1 for x in D['valence_arousal_label']]
Y1 = [x[1]-1 for x in D['valence_arousal_label']]
model = LogisticRegression()
scores = cross_val_score(model, X, Y0,cv=5)
print("Cross validation scores:{}".format(scores))
print("Mean cross validation score:{:2f}".format(scores.mean()))
model = LogisticRegression()
scores = cross_val_score(model, X, Y1,cv=5)
print("Cross validation scores:{}".format(scores))
print("Mean cross validation score:{:2f}".format(scores.mean()))

#MAHNOB
length = len(T['EEG_emotion_category'])
X =  []
L = T['EEG_feature']
scaler = preprocessing.MinMaxScaler()
L = scaler.fit_transform(L).tolist()
#最大最小处理
P = ohe.fit_transform(T['EEG_emotion_category']).toarray().tolist()
Q = ohe.fit_transform([[x[0]] for x in T['subject_video']]).toarray().tolist()

#独热码
#print(P)
for i in range(0,length):
	tem = L[i]+P[i]+T['subject_video'][i]
	X.append(tem)
#print(X)
#正则化
#X = preprocessing.normalize(X, norm='l2')
#print(X)
Y = [x[0]*x[1] for x in T['valence_arousal_label'] ]
Y0 = [x[0]-1 for x in T['valence_arousal_label']]
Y1 = [x[1]-1 for x in T['valence_arousal_label']]
#分解为两个逻辑变量
model = LogisticRegression()
scores = cross_val_score(model, X, Y0,cv=5)
print("Cross validation scores:{}".format(scores))
print("Mean cross validation score:{:2f}".format(scores.mean()))
model = LogisticRegression()
scores = cross_val_score(model, X, Y1,cv=5)

print("Cross validation scores:{}".format(scores))
print("Mean cross validation score:{:2f}".format(scores.mean()))