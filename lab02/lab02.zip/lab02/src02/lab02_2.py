from sklearn.neural_network import MLPClassifier
import math
import random
from sklearn.preprocessing import OneHotEncoder

import numpy as np
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import Dropout
from keras.optimizers import SGD
from keras.wrappers.scikit_learn import KerasClassifier
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
from sklearn.model_selection import StratifiedKFold

from keras.constraints import max_norm
import warnings
warnings.filterwarnings('ignore')
#使用预处理
from sklearn import preprocessing
from sklearn.svm import SVC
import random

def relu(x):
	return max(0,x)

def my_drop_out(x,p):
	r = random.randint(0,100)
	if(r<100*p):
		return 0
	return x

S=[]
T={}
D={}
with open('../data/MAHNOB-HCI/valence_arousal_label.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
T['valence_arousal_label'] = S
S=[]
with open('../data/MAHNOB-HCI/EEG_feature.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([float(i) for i in line])
T['EEG_feature'] = S
S=[]
with open('../data/MAHNOB-HCI/subject_video.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
T['subject_video'] = S
S=[]
with open('../data/MAHNOB-HCI/EEG_emotion_category.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
T['EEG_emotion_category'] = S

S = []
with open('../data/DEAP/EEG_feature.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([float(i) for i in line])
D['EEG_feature'] = S
S = []
with open('../data/DEAP/subject_video.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
D['subject_video'] = S
S = []
with open('../data/DEAP/valence_arousal_label.txt', 'r') as file_object:
	for line in file_object:
		line = line.strip('\n')
		line = line.split('\t')
		if (line[-1] == ''):
			line.pop(-1)
		if len(line) != 0:
			S.append([int(i) for i in line])
D['valence_arousal_label'] = S
ohe = OneHotEncoder(categorical_features=[0])
#DEAP
length = len(D['EEG_feature'])
X = []
for x in range(0,length):
	X.append(D['EEG_feature'][x] + D['subject_video'][x])
scaler = preprocessing.MinMaxScaler()
X = scaler.fit_transform(X)
Y2 = np.array(D['valence_arousal_label'])
#归一化
#训练验证
kfold = KFold(n_splits=5, shuffle=True, random_state=7)
cvscores1 = []
for train, test in kfold.split(X, Y2):
	model = Sequential()
	model.add(Dense(units=100, activation='relu', input_dim=162, kernel_constraint=max_norm(3)))
	model.add(Dropout(rate=0.2))
	model.add(Dense(units=200, activation='relu', kernel_constraint=max_norm(3)))
	model.add(Dropout(rate=0.2))
	model.add(Dense(units=2, activation='softmax'))

	# 定义Dropout
	sgd = SGD(lr=0.01, momentum=0.8, decay=0.0, nesterov=False)
	# 编译模型
	model.compile(loss='categorical_crossentropy', optimizer=sgd, metrics=['accuracy'])
	model.fit(x=X[train] , y=Y2[train] , epochs=5 , batch_size=10)
	scores = model.evaluate(x=X , y=Y2)
	cvscores1.append(scores[1]*100)
	#print('%s: %.2f%%' % (model.metrics_names[1],scores[1]*100))

#MAHNOB

length = len(T['EEG_emotion_category'])
X =  []
L = T['EEG_feature']
scaler = preprocessing.MinMaxScaler()
L = scaler.fit_transform(L).tolist()
#最大最小处理

P = ohe.fit_transform(T['EEG_emotion_category']).toarray().tolist()
Q = ohe.fit_transform([[x[0]] for x in T['subject_video']]).toarray().tolist()

#独热码
#print(P)
for i in range(0,length):
	tem = L[i]+P[i]+T['subject_video'][i]
	X.append(tem)
#print(X)
#正则化
#X = preprocessing.normalize(X, norm='l2')
#print(X)
Y2 = np.array(T['valence_arousal_label'])
X = np.array(X)
cvscores2 = []
for train, test in kfold.split(X, Y2):

	model = Sequential()
	model.add(Dense(units=100, activation='relu', input_dim=171, kernel_constraint=max_norm(3)))
	model.add(Dropout(rate=0.2))
	model.add(Dense(units=200, activation='relu', kernel_constraint=max_norm(3)))
	model.add(Dropout(rate=0.2))
	model.add(Dense(units=2, activation='softmax'))

	# 定义Dropout
	sgd = SGD(lr=0.01, momentum=0.8, decay=0.0, nesterov=False)
	# 编译模型
	model.compile(loss='categorical_crossentropy', optimizer=sgd, metrics=['accuracy'])
	model.fit(x=X[train] , y=Y2[train] , epochs=5 , batch_size=10)
	scores = model.evaluate(x=X , y=Y2)
	cvscores2.append(scores[1]*100)

#DEAP id
length = len(D['EEG_feature'])
X = []
for x in range(0,length):
	X.append(D['EEG_feature'][x] + D['valence_arousal_label'][x])
scaler = preprocessing.MinMaxScaler()
X = scaler.fit_transform(X)
Y2 = ohe.fit_transform([[x[0]] for x in D['subject_video']]).toarray()
print(X.shape)
print(Y2.shape)
#归一化
#训练验证
kfold = KFold(n_splits=5, shuffle=True, random_state=7)
cvscores3 = []
for train, test in kfold.split(X, Y2):

	model = Sequential()
	model.add(Dense(units=100, activation='relu', input_dim=162, kernel_constraint=max_norm(3)))
	model.add(Dropout(rate=0.2))
	model.add(Dense(units=200, activation='relu', kernel_constraint=max_norm(3)))
	model.add(Dropout(rate=0.2))
	model.add(Dense(units=32, activation='softmax'))

	# 定义Dropout
	sgd = SGD(lr=0.01, momentum=0.8, decay=0.0, nesterov=False)
	# 编译模型
	model.compile( loss='categorical_crossentropy',optimizer=sgd, metrics=['accuracy'])
	model.fit(x=X[train] , y=Y2[train] , epochs=5 , batch_size=10)
	scores = model.evaluate(x=X , y=Y2)
	cvscores3.append(scores[1]*100)
#MAHNOB id

length = len(T['EEG_emotion_category'])
X =  []
L = T['EEG_feature']
scaler = preprocessing.MinMaxScaler()
L = scaler.fit_transform(L).tolist()
#最大最小处理
P = ohe.fit_transform(T['EEG_emotion_category']).toarray().tolist()
Q = ohe.fit_transform([[x[0]] for x in T['subject_video']]).toarray().tolist()

#独热码
#print(P)
for i in range(0,length):
	tem = L[i]+P[i]+T['valence_arousal_label'][i]
	X.append(tem)
#print(X)
#正则化
#X = preprocessing.normalize(X, norm='l2')
#print(X)
Y2 = ohe.fit_transform([[x[0]] for x in T['subject_video']]).toarray()
X = np.array(X)
cvscores4 = []
for train, test in kfold.split(X, Y2):

	model = Sequential()
	model.add(Dense(units=100, activation='relu', input_dim=171, kernel_constraint=max_norm(3)))
	model.add(Dropout(rate=0.2))
	model.add(Dense(units=200, activation='relu', kernel_constraint=max_norm(3)))
	model.add(Dropout(rate=0.2))
	model.add(Dense(units=27, activation='softmax'))

	# 定义Dropout
	sgd = SGD(lr=0.01, momentum=0.8, decay=0.0, nesterov=False)
	# 编译模型
	model.compile(loss='categorical_crossentropy', optimizer=sgd, metrics=['accuracy'])
	model.fit(x=X[train] , y=Y2[train] , epochs=5 , batch_size=10)
	scores = model.evaluate(x=X , y=Y2)
	cvscores4.append(scores[1]*100)

#category
length = len(T['EEG_emotion_category'])
X =  []
L = T['EEG_feature']
scaler = preprocessing.MinMaxScaler()
L = scaler.fit_transform(L).tolist()
#最大最小处理
P = ohe.fit_transform(T['EEG_emotion_category']).toarray().tolist()
Q = ohe.fit_transform([[x[0]] for x in T['subject_video']]).toarray().tolist()

#独热码
#print(P)
for i in range(0,length):
	tem = L[i]+T['subject_video'][i]+T['valence_arousal_label'][i]
	X.append(tem)
#print(X)
#正则化
#X = preprocessing.normalize(X, norm='l2')
#print(X)
Y2 = ohe.fit_transform([[x[0]] for x in T['EEG_emotion_category']]).toarray()

X = np.array(X)
cvscores5 = []
kfold = KFold(n_splits=5, shuffle=True, random_state=7)

for train, test in kfold.split(X, Y2):

	model = Sequential()
	model.add(Dense(units=100, activation='relu', input_dim=164, kernel_constraint=max_norm(3)))
	model.add(Dropout(rate=0.2))
	model.add(Dense(units=200, activation='relu', kernel_constraint=max_norm(3)))
	model.add(Dropout(rate=0.2))
	model.add(Dense(units=9, activation='softmax'))

	# 定义Dropout
	sgd = SGD(lr=0.01, momentum=0.8, decay=0.0, nesterov=False)
	# 编译模型
	model.compile(loss='categorical_crossentropy', optimizer=sgd, metrics=['accuracy'])
	model.fit(x=X[train] , y=Y2[train] , epochs=5 , batch_size=10)
	scores = model.evaluate(x=X , y=Y2)
	cvscores5.append(scores[1]*100)

print(cvscores1,np.average(cvscores1))
print(cvscores2,np.average(cvscores2))
print(cvscores3,np.average(cvscores3))
print(cvscores4,np.average(cvscores4))